﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using RestAPI.Models;

namespace RestAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoboController : ControllerBase
    {
        // GET: api/Robo
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Robo/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return id.ToString();
        }

        // POST: api/Robo/5
        [HttpPost("{id}/{metodo}")]
        public string Post(int id, string metodo, [FromBody] Estante value)
        {
            Robo robo = BancoDeDados.Robos.FirstOrDefault(r => r.ID == id);
            if (robo == null)
                return "Não foi possível encontrar o Robo de ID " + id;
            switch (metodo) {
                case "VerificarDistancia":
                    return robo.VerificarDistancia(value).ToString();
                default:
                    return "É necessário passar um método para ser executado (api/{id}/{metodo})";
            }
        }

        // PUT: api/Robo/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
